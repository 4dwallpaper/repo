const mongoose = require('mongoose');
// const chalk=require('chalk');
// import chalk from 'chalk';

let url= "mongodb+srv://Ankush:ankush123@cluster0.6uhhg5l.mongodb.net/?retryWrites=true&w=majority";

mongoose.connect(
    url,
    {useNewUrlParser:true},
    (err) => {
        if (err){
            console.error('Error in Connecting MongoDB');
            console.log(err);
        }
        else{
            console.log('Connected to Mongodb ');
        }
    }

);

