const express=require('express')
const chatController = require('../controllers/chatgptController');
const router=express.Router();

router.post('/chatgpt', function(req,res){
chatController.chatgpt});

module.exports = router;