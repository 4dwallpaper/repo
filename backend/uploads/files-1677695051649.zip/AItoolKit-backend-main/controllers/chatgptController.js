const { Configuration, OpenAIApi } = require("openai");
const OPENAI_API_KEY = "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"
exports.chatgpt = async (req, res) => {
  const { model, prompt, temperature, max_tokens, echo, stop, } = req.body;

  const configuration = new Configuration({
    apiKey: OPENAI_API_KEY,
  });
  const openai = new OpenAIApi(configuration);
  try {
    const response = await openai.createCompletion({
      prompt: prompt.join('\n'), temperature: 0.85, max_tokens: 4000, model: "text-davinci-003", echo: false, max_tokens: 4000, stop: '\n',
    });
    res.status(200).json({
      response: response.data.choices[0].text,
    })
  }
  catch (err) {
    res.status(500).json({ err: err.message })
  }
}