const mongoose = require("mongoose");



const UserOTPVerification = mongoose.model("UserOTPVerfication", UserOTPVerificationSchema);

module.exports = UserOTPVerification;