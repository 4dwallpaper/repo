const bcrypt = require('bcryptjs');
const User = require('../models/userModel');
const { sendMail } = require("../middleware/sendMail");

exports.googleAuth = async (req, res) =>{
    try{
        const {email} = req.body;
        if(email){
            const userExist = await User.findOne({email});
            if(userExist){
                if(!userExist.verified){
                    await User.updateOne({email}, {verified: true});
                    const user = await User.findOne({email})
                    return res.status(200).json({
                        user
                    })
                }
                else{
                    return res.status(200).json({
                        user: userExist
                    })
                }
            }   
            else{
            const newUser = new User({
                email,
                verified: true,
                coin: 200,
                password:""
            })
            await newUser.save();
            res.status(200).json({
                user: newUser
            })
        }
        }
        else{
            throw Error("Google Authentication failed")
        }
    }
    catch(err){
        res.status(400).json({
            err: err.message
        })
    }
}

exports.authentication = async (req, res) => {
    try {
        let { email, password } = req.body;

        // let emailExists = await User.findOne({ email });
        // if (emailExists) {
        //     throw new Error("Email already exists");
        // }

        let userExist = await User.findOne({ email });
        if (userExist) {
            if (!userExist.verified) {
                // userExist.verified = false;
                // await userExist.save();
                sendOTPVerificationEmail(userExist, res);
                // return res.status(200).json({
                //     status:"Success"
                // })
            } else {
                
                let match = await bcrypt.compare(password, userExist.password);
                if (match) {
                    res.status(200).json({
                        status: "Success",
                        userData: userExist
                    });
                } else {
                    throw { message: "Email or password doesn't match" };
                }
            }
        } else {
            let salt = await bcrypt.genSalt(10);
            let securePassword = await bcrypt.hash(password, salt);
            let newUser = await User({
                email: email,
                password: securePassword,
                verified: false,
                coin: 200
            });
            let savedUser = await newUser.save();
            await sendOTPVerificationEmail(savedUser);
            res.status(200).json({
                status: "PENDING",
                message: "Verification OTP email sent"
            });
        }
    } catch (err) {
        res.status(400).json({
            error: { err : err.message, test :"test"}
        });
    }
};

const sendOTPVerificationEmail = async (savedUser, res) => {
    try {
        const otpPresent = await User.findOne({ email: savedUser.email })
        if (otpPresent.userVerify.expireAt >= Date.now()) {
            throw new Error("Otp has been already sent to your email");
        }

        let otp = `${Math.floor(1000 + Math.random() * 9000)}`;
        let salt = await bcrypt.genSalt(10);
        let secureOTP = await bcrypt.hash(otp, salt);

        let newOTPVerification = {
            email: savedUser.email,
            otp: secureOTP,
            createdAt: Date.now(),
            expireAt: Date.now() + 1 * 600000
        };

        const user = await User.findOne({ email: savedUser.email });
        user.userVerify = newOTPVerification;
        await user.save(newOTPVerification);
        await sendMail({
            email: user.email,
            subject: "OTP for verification at Chat GPT",
            html: `<p><b>${otp}</b> is your OTP for verification at Chat GPT</p>
            <p>This OTP is valid only for 5 minutes</p>
            <p>Thanks and Regards,</p>
            <p>Team Chat GPT</p>`
        });

        await user.save();
        // const otpVerified = await User.findOne({ email: savedUser.email, verified: "true" });
        // if (otpVerified) {
        // } else {
        //   await User.deleteOne({ email: savedUser.email });
        // }

    } catch (error) {
        res.status(400).json({
            status: "Failed",
            error: error.message
        })
        // console.log(error);
    }
};


exports.verifyOTP = async (req, res) => {
    try {
        const { email, otp } = req.body;
        if (!email || !otp) {
            throw new Error("Email and OTP are required");
        }
        const user = await User.findOne({ email });
        if (!user || user.verified) {
            throw new Error("User not found or already verified");
        }
        const { expireAt, otp: securedOTP } = user.userVerify;
        if (expireAt < Date.now()) {
            throw new Error("OTP has expired");
        }
        const validOTP = await bcrypt.compare(otp, securedOTP);
        if (!validOTP) {
            throw new Error("Invalid OTP");
        }
        await User.updateOne({ email }, { verified: true });
        const userData = await User.findOneAndUpdate({ email: email}, { $unset: { userVerify: '' } })

    res.json({
        status: "success",
        userData: userData,
    });
} catch (error) {
    res.status(400).json({ status: "error", message: error.message });
}
};

exports.resendOTP = async (req, res) => {
    try {
        let { email } = req.body;
        const user = await User.findOne({ email });
        if (!user) {
            throw Error("Email doesn't exist");
        }
        if (!email) {
            throw Error("Empty user details are not allowed");
        }
        else {
            sendOTPVerificationEmail({ email }, res);
            res.json({
                status: "Success",
                message: "OTP Resend successfully",
                code: 200
            })
        }
    }
    catch (error) {
        res.json({
            status: "FAILED",
            message: error.message,
            code: 500
        })
    }
}

exports.forgotPassword = async (req, res) => {
    try {
        let { email } = req.body;
        if (!email) {
            res.status(502).json({
                status: "FAILED",
                message: "Email is required"
            })
        }
        else {
            sendOTPVerificationEmail(userExist, res);
        }
    }
    catch (err) {
        res.json({
            status: "FAILED",
            message: err.message,
            code: 500
        })
    }
}

exports.resetPassword = async (req, res) => {
    try {
        const { email, password } = req.body;
        const emailExist = await User.find({ email });
        if (emailExist) {
            res.json({
                status: "FAILED",
                message: "user email not verified",
                code: 500
            })
        }
        else {
            const salt = await bcrypt.genSalt(10);
            const securePassword = await bcrypt.hash(password, salt);
            const updateUser = await User.findOneAndUpdate({ email }, { password: securePassword });
            User.save(updateUser);
            res.json({
                status: "Success",
                message: "User password updated successfully",
                code: 200
            })
        }
    }
    catch (err) {
        res.json({
            status: "FAILED",
            message: err.message,
            code: 400
        })
    }
}