// require('dotenv').config()

const express = require('express');
require('./database/db');
const index=require('./routes/index');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();

app.use(express.json({ limit: "100mb" }));
app.use(bodyParser.urlencoded({ extended: true, limit: "100mb" }));
app.use(
  cors({
      credentials: true,
      origin: "http://localhost:3000",
  })
);


app.use(
  express.urlencoded({ extended: true })
);

app.use("/api",index)



const port  = 4003;

app.listen(port , function(){
    console.log(`Server Started on ${port}`);
});