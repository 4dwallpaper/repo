
const express = require('express');
const userController = require('../controllers/userController');
const SendMail = require('../middleware/sendMail')
const router = express.Router();

router.post('/googleAuth', userController.googleAuth);
router.post('/authentication', userController.authentication);
router.post("/verifyOTP", userController.verifyOTP);
router.post("/resendOTPVerificationCode", userController.resendOTP);
router.post("/forgotPasswordOTP", userController.forgotPassword);
router.post("/resetPassword", userController.resetPassword);
module.exports = router;

