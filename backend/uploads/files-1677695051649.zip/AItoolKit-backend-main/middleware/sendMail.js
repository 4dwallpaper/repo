const nodeMailer = require("nodemailer");

exports.sendMail = async (options) => {
  const transporter = nodeMailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    service: "Gmail",
    auth: {
      user: "ankushrana830@gmail.com",
      pass: "zuepfpjigknigxxi",
    },
  });

  const mailOptions = {
    from: "ankushrana830@gmail.com",
    to: options.email,
    subject: options.subject,
    html: options.html,
  };
  await transporter.sendMail(mailOptions);
};
